1、下载数据文件并抽取相应字段合并：Download_Maude_Data_2.py
2、对一些字段和类型等的分析:Da_Vinci_MDR_Malfunction_Impacts_7_2.py
3、图表：Analysis.py