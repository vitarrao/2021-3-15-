# coding=utf-8
import bs4
import requests
import csv
import pandas as pd
import re
from tqdm import tqdm
from multiprocessing import Pool

regex = re.compile(r'\s*[\n\r\t]')


def Get_Other_Fields(MDR_Link):
    # Open each MDR Link
    # time.sleep(0.25)

    # result = urllib2.urlopen(MDR_Link)
    try:
        r = requests.get(MDR_Link)
    except Exception, e:
        print('network exception, link: %s' % MDR_Link)
        return ['N/A','N/A', 'N/A']
    # soup = bs4.BeautifulSoup(r.text, features='html.parser')
    soup = bs4.BeautifulSoup(r.text, 'lxml')  # ljn changed, html.parser is slow

    ##### Patient Outcome, Event Description, and Manufacturer Narrative
    # regex = re.compile(r'\s*[\n\r\t]')
    Patient_Outcome = 'N/A'
    Event = ''
    Narrative = ''
    try:
        for st in soup.findAll('strong'):
            # Patient Outcome
            if (st.string.count('Patient Outcome') > 0):
                if (st.next.next != ''):
                    Raw_Outcome = st.next.next
                    Patient_Outcome = regex.sub('', Raw_Outcome).strip().encode('ascii', 'ignore').replace("&nbsp;", "")

            # Event Description
            if (st.string.find('Event Description') > 0):
                if (st.findNext('p').contents != []):
                    Raw_Event = st.findNext('p').contents[0]
                    Event = Event + regex.sub('', Raw_Event).strip().encode('ascii', 'ignore') + ' '

            # Manufacturer Narrative
            if (st.string.find('Manufacturer Narrative') > 0):
                if (st.findNext('p').contents != []):
                    Raw_Narrative = st.findNext('p').contents[0]
                    Narrative = Narrative + regex.sub('', Raw_Narrative).strip().encode('ascii', 'ignore') + ' '
        # If not found any narrative or event description
        if (Event == ''):
            Event = 'N/A'
        if (Narrative == ''):
            Narrative = 'N/A'

            ##### Number of Devices
        for st in soup.findAll('th'):
            if (len(st.contents) > 1):
                if ((st.contents[1].string.strip().encode('ascii', 'ignore').count(
                        'Device Was Involved in the Event') > 0) or
                        (st.contents[1].string.strip().encode('ascii', 'ignore').count(
                            'DeviceS WERE Involved in the Event') > 0)):
                    # Number_Devices = st.contents[0].contents[0].string.strip().encode('ascii','ignore') # ljn changed
                    break
        return [Patient_Outcome, Event, Narrative]
    except Exception, e:
        print('Extraction error! link: %s' % MDR_Link)
        return ['N/A', 'N/A', 'N/A']



if __name__ == '__main__':
    y = 2018
    dir = './ExtractedFiles/' + str(y) + '/'
    infile = dir + 'daVinci_MAUDE_Data_'+str(y) + '.csv'
    df = pd.read_csv(infile)
    df1 = pd.read_csv(dir + 'daVinci_MAUDE_Data_2018full.csv')
    MDR_Link = df['MDR_Link']
    p = Pool(20)

    # get the Patient_Outcome, Event, Narrative
    Patient_Outcome = []
    Event = []
    Narrative = []
    print('begin parser other fields!')
    links = MDR_Link.values
    results = p.map(Get_Other_Fields, links)
    for res in results:
        Patient_Outcome.append(res[0])
        Event.append(res[1])
        Narrative.append(res[2])
    Patient_Outcome = pd.Series(Patient_Outcome)
    Event = pd.Series(Event)
    Narrative = pd.Series(Narrative)

    tmp_dict = {'Patient_Outcome': Patient_Outcome.values,
                'Event': Event.values,
                'Narrative': Narrative.values}
    tmp_df = pd.DataFrame.from_dict(tmp_dict)
    try:
        tmp_df.to_excel(dir + 'other_field_' + str(y)+'.xls', index=False, header=True)
    except:
        print('other field save to xls field!')
        tmp_df.to_csv(dir + 'other_field_' + str(y)+'.csv', index=False, header=True)

    print('to csv files:')
    df['Patient_Outcome'] = Patient_Outcome
    df['Event'] = Event
    df['Narrative'] = Narrative
    df.to_csv(infile, index=False, header=True)


    df1['Patient_Outcome'] = Patient_Outcome
    df1['Event'] = Event
    df1['Narrative'] = Narrative
    try:
        df1.to_excel(dir + 'daVinci_MAUDE_Data_2018full.xls', index=False, header=True)
    except:
        print('df1 save to excel failed!')
        df1.to_csv(dir + 'daVinci_MAUDE_Data_2018full.csv', index=False, header=True)
    print('end')

