# coding=utf-8
# Downloads all the MAUDE (including FOIDEV and MDRFOI) files from the FDA Website
# Searches for the records related to a specific device
# Merges the FIODEV and MDRFOI files into one Excel sheet
# Goes through MDR keys and opens up the MDR reports on FDA website to grab and add
# Patient outcome, Event Description and Narrative, and Number of Devices to the table
# import sys
# reload(sys)
# sys.setdefaultencoding('utf8')
import urllib, urllib2, cookielib
import bs4
import csv
import pandas as pd
import re
import numpy as np
from nltk.probability import ConditionalFreqDist
from nltk.tokenize import word_tokenize
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import stopwords
import string
from zipfile import ZipFile
import os
import xlrd, xlwt
import xlsxwriter  # xlwt不支持超过256行的写入,需要采用xlsxwriter
import time
from datetime import date
from dateutil import parser

cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
import requests
from tqdm import tqdm
import time
from multiprocessing import Pool


#### Extract the fields from each record
def FieldExtract(line, field_numbers):
    fields = line.split('|')
    # print('ljn: %d' % (len(fields))) # some is 28, lower than 45
    # print('ljn: %s' % line) # one record is not complete

    extracted = []  # [0 for x in range(0,len(line))]
    try:  # ljn changed
        for f in field_numbers:
            extracted.append(fields[f - 1].strip())
        # print extracted
        return extracted
    except Exception, e:
        # print('Record  occurs errors, length is %d,record is %s' % (len(fields), line))
        # print(e.message)
        return None


def FieldExtract2(line, field_numbers):
    extracted = []
    try:  # ljn changed
        for f in field_numbers:
            extracted.append(line[f - 1].strip())
        # print extracted
        return extracted
    except Exception, e:
        print('Record  occurs errors, record is %s' % line)
        print(e.message)
        return None


# Download the data files from MAUDE database and save it
def MAUDE_Download(FOIDEV_files, MDRFOI_files, data_dir):
    # MAUDE_url = 'https://www.fda.gov/medical-devices/mandatory-reporting-requirements-manufacturers-importers-and-device-user-facilities/manufacturer-and-user-facility-device-experience-database-maude'
    MAUDE_url = 'https://www.accessdata.fda.gov/MAUDE/ftparea/'  # ljn added
    os.chdir(data_dir)
    # Download All FOIDEV files   
    for filename in FOIDEV_files + MDRFOI_files:
        # Download the Zip file
        with open(data_dir + filename + '.zip', 'wb') as zfile:
            print(MAUDE_url + filename + '.zip')
            zfile.write(urllib2.urlopen(MAUDE_url + filename + '.zip').read())
        # Extract the Zip file
        zip_data = ZipFile(data_dir + filename + '.zip', 'r').extractall(data_dir)  # ljn changed
        # Clean up the folder by deleting the Zip file
        os.remove(data_dir + filename + '.zip')
        print (filename + ' downloaded.')


# Extract the FOIDEV records and append them to the file
def FOIDEVExtract(FOIDEV_files, FOIDEV_Field_Numbers, device_name, device_keywords, data_dir, save_dir):  # ljn changed
    foidev_count = 0
    global current_year

    print('Starting to extract da Vinci related records..')
    f = open(save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'foidev.csv', 'wb')
    csv_wr = csv.writer(f, dialect='excel', delimiter=',')
    # Extract those related to the device
    for filename in FOIDEV_files:
        # If the first file, first get the titles
        # FOIDEV_Field_Numbers = get_numbers(filename) # ljn added
        if filename == FOIDEV_files[0]:
            with open(data_dir + filename + '.txt', "rb") as foidev_file:
                title = foidev_file.next()

                # Create the Hash Table of FOIDEV records
                FOIDEV_Titles = FieldExtract(title, FOIDEV_Field_Numbers)
                # Write the titles
                csv_wr.writerow(FOIDEV_Titles)
                device_MDR_Hash = {'MDR_Key': FOIDEV_Titles}
            foidev_file.close()

        # Extract only those FOIDEV records related to the Device
        # => Write in the Hash Table and in 'device_FOIDEV.txt'        
        with open(data_dir + filename + '.txt', "rb") as foidev_file:
            for line in foidev_file:
                for k in device_keywords:
                    if line.lower().find(k) > -1:
                        MDR_Key = line.split('|')[0]
                        if (not device_MDR_Hash.has_key(MDR_Key)):
                            # print MDR_Key;
                            FOIDEV_Fields = FieldExtract(line, FOIDEV_Field_Numbers)
                            if (FOIDEV_Fields is not None):  # ljn changed
                                device_MDR_Hash[MDR_Key] = FOIDEV_Fields
                                foidev_count = foidev_count + 1
                                # print foidev_count
                                # Write FOIDEV Columns
                                csv_wr.writerow(FOIDEV_Fields)
            foidev_file.close()
    # print (str(" ".join('%s' % id for id in foidev_count)+' FOIDEV records extracted and added to the table.'))
    # print (str(" ".join('%d' % id for id in range(1, foidev_count+1)) + ' FOIDEV records extracted and added to the table.'))
    print(str(" ".join('%d' % foidev_count) + ' FOIDEV records extracted and added to the table.'))
    f.close()
    return device_MDR_Hash


### Extract the FOIDEV records and append them to the file
def FOIDEVExtract2(FOIDEV_files, FOIDEV_Field_Numbers, device_name, device_codes, data_dir):
    foidev_count = 0
    os.chdir(data_dir)

    # Extract those related to the device
    for filename in FOIDEV_files:
        # If the first file, first get the titles
        if (filename == FOIDEV_files[0]):
            with open(data_dir + filename + '.txt', "rb") as foidev_file:
                title = foidev_file.next()

                # Create the Hash Table of FOIDEV records
                FOIDEV_Titles = FieldExtract(title, FOIDEV_Field_Numbers)
                device_MDR_Hash = {'MDR_Key': FOIDEV_Titles}

                # Write the titles
                with open(device_name + '_FOIDEV.txt', "w") as myfile:
                    myfile.write('|'.join(FOIDEV_Titles) + '\n')
                myfile.close()

        foidev_file.close()

        # Extract only those FOIDEV records related to the Device
        # => Write in the Hash Table and in 'device_FOIDEV.txt'
        with open(data_dir + filename + '.txt', "rb") as foidev_file:
            for line in foidev_file:
                for k in device_codes:
                    if (line.find(k) > -1):
                        MDR_Key = line.split('|')[0]
                        if (not device_MDR_Hash.has_key(MDR_Key)):
                            # print MDR_Key;
                            FOIDEV_Fields = FieldExtract(line, FOIDEV_Field_Numbers)
                            device_MDR_Hash[MDR_Key] = FOIDEV_Fields
                            foidev_count = foidev_count + 1
                            # print foidev_count
                            # Write FOIDEV Columns
                            with open(device_name + '_FOIDEV.txt', "a") as myfile:
                                myfile.write('|'.join(FOIDEV_Fields) + '\n')
                            myfile.close()
                            break
        foidev_file.close()

    print (str(foidev_count) + ' FOIDEV records extracted and added to the table.')
    return device_MDR_Hash


regex = re.compile(r'\s*[\n\r\t]')


def Get_Other_Fields(MDR_Link):
    # Open each MDR Link
    # time.sleep(0.25)

    # result = urllib2.urlopen(MDR_Link)
    try:
        r = requests.get(MDR_Link)
    except Exception, e:
        print('network exception, link: %s' % MDR_Link)
        return ['N/A', 'N/A', 'N/A']
    # soup = bs4.BeautifulSoup(r.text, features='html.parser')
    soup = bs4.BeautifulSoup(r.text, 'lxml')  # ljn changed, html.parser is slow

    ##### Patient Outcome, Event Description, and Manufacturer Narrative
    # regex = re.compile(r'\s*[\n\r\t]')
    Patient_Outcome = 'N/A'
    Event = ''
    Narrative = ''
    try:
        for st in soup.findAll('strong'):
            # Patient Outcome
            if (st.string.count('Patient Outcome') > 0):
                if (st.next.next != ''):
                    Raw_Outcome = st.next.next
                    Patient_Outcome = regex.sub('', Raw_Outcome).strip().encode('ascii', 'ignore').replace("&nbsp;", "")

            # Event Description
            if (st.string.find('Event Description') > 0):
                if (st.findNext('p').contents != []):
                    Raw_Event = st.findNext('p').contents[0]
                    Event = Event + regex.sub('', Raw_Event).strip().encode('ascii', 'ignore') + ' '

            # Manufacturer Narrative
            if (st.string.find('Manufacturer Narrative') > 0):
                if (st.findNext('p').contents != []):
                    Raw_Narrative = st.findNext('p').contents[0]
                    Narrative = Narrative + regex.sub('', Raw_Narrative).strip().encode('ascii', 'ignore') + ' '
        # If not found any narrative or event description
        if (Event == ''):
            Event = 'N/A'
        if (Narrative == ''):
            Narrative = 'N/A'

            ##### Number of Devices
        for st in soup.findAll('th'):
            if (len(st.contents) > 1):
                if ((st.contents[1].string.strip().encode('ascii', 'ignore').count(
                        'Device Was Involved in the Event') > 0) or
                        (st.contents[1].string.strip().encode('ascii', 'ignore').count(
                            'DeviceS WERE Involved in the Event') > 0)):
                    # Number_Devices = st.contents[0].contents[0].string.strip().encode('ascii','ignore') # ljn changed
                    break
        return [Patient_Outcome, Event, Narrative]
    except Exception, e:
        print('Extraction error! link: %s' % MDR_Link)
        return ['N/A', 'N/A', 'N/A']


def MDRFOIExtract(device_MDR_Hash, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
                  MDRFOI_Field_Numbers, device_name, data_dir, save_dir):
    global current_year
    MAUDE_Keys = []
    f = open(save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'mdrdev.csv', 'wb')
    csv_wr = csv.writer(f, dialect='excel', delimiter=',')
    # Extract the Titles of Fields of Interest
    # FOIDEV_Titles
    # with open(data_dir + FOIDEV_files[0] + '.txt', "rb") as foidev_file:
    #     # FOIDEV_Field_Numbers = get_numbers(FOIDEV_files[0]) # LJN CHANGED
    #     title = foidev_file.next().strip()
    #     FOIDEV_titles = FieldExtract(title, FOIDEV_Field_Numbers)
    #     csv_wr1.writerow(FOIDEV_titles)
    #
    # device_MDR_Hash = {'MDR_Key': FOIDEV_titles}
    # with open(save_dir + device_name+'_FOIDEV.txt', "r") as foidev_file:
    #     # Skip the title
    #     title = foidev_file.next()
    #     for line in foidev_file:
    #         FOIDEV_Fields = line.split('|')
    #         # print(FOIDEV_Fields)
    #         csv_wr1.writerow(FOIDEV_Fields)
    #         MDR_Key = FOIDEV_Fields[0].strip()
    #         device_MDR_Hash[MDR_Key] = FOIDEV_Fields
    #         #print FOIDEV_Fields;
    print('Number of records = ' + str(len(device_MDR_Hash)) + '\n')

    j = 0
    for filename in MDRFOI_files:
        with open(data_dir + filename + '.txt', 'rb') as mdrfoi_file:
            # the MDRFOI  title
            title = FieldExtract(mdrfoi_file.next(), MDRFOI_Field_Numbers)
            if filename == MDRFOI_files[0]:
                csv_wr.writerow(title)
            recyear_idx = title.index('DATE_RECEIVED')  # the receive year index
            for i, line in enumerate(mdrfoi_file):
                text = FieldExtract(line, MDRFOI_Field_Numbers)
                if text == None:
                    continue
                MDR_Key = text[0].strip()

                # 确保与foidev文件里解析出的结果 有相同MDR_KEY
                if (device_MDR_Hash.has_key(MDR_Key)):
                    if (text[recyear_idx] != ''):
                        Report_DateStr = text[recyear_idx]
                        Report_Date = parser.parse(Report_DateStr)
                        Report_Year = str(Report_Date.year)
                    else:
                        Report_Date = 'N/A'
                        Report_Year = 'N/A'
                    try:
                        if (int(Report_Year) <= current_year):
                            csv_wr.writerow(text)
                            # Remove the record from the hash to avoid duplicate records
                            device_MDR_Hash.pop(MDR_Key)
                            j += 1
                    except:
                        pass

    print('write %d items' % j)
    print 'filename %s ' % (save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'mdrdev.csv')
    return save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'mdrdev.csv'


def MergeMaudeXlsx(current_year, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
                   MDRFOI_Field_Numbers, device_name, save_dir):
    """将前面解析出的foidev文件里的字段和mdrfoi文件里字段合并起来，并对一些N/A进行适当的处理"""
    # MAUDE_Keys = []
    # AllCounts = [0, 0, 0]
    infile = save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'mdrdev.csv'
    infile1 = save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'foidev.csv'
    df_mdrfoi = pd.read_csv(infile, dtype=str).fillna(value='')
    df_foidev = pd.read_csv(infile1, dtype=str).fillna(value='')
    MDRFOI_titles = df_mdrfoi.columns.tolist()
    FOIDEV_titles = df_foidev.columns.tolist()
    last_col = df_foidev[FOIDEV_titles[-1]]
    last_col[last_col == '\n'] = ''
    df_foidev[FOIDEV_titles[-1]] = last_col
    device_MDR_Hash = {'MDR_Key': FOIDEV_titles}
    del (FOIDEV_titles[0])
    print(FOIDEV_titles)
    print(MDRFOI_titles)

    '''
    ['DEVICE_EVENT_KEY', 'BRAND_NAME', 'GENERIC_NAME', 'MANUFACTURER_D_NAME', 'MODEL_NUMBER', 'DEVICE_REPORT_PRODUCT_CODE', 'DEVICE_AGE_TEXT']
    ['MDR_REPORT_KEY', 'EVENT_KEY', 'REPORT_NUMBER', 'REPORT_SOURCE_CODE', 'NUMBER_DEVICES_IN_EVENT', 'NUMBER_PATIENTS_IN_EVENT', 'DATE_RECEIVED', 
    'ADVERSE_EVENT_FLAG', 'PRODUCT_PROBLEM_FLAG', 'DATE_REPORT', 'DATE_OF_EVENT', 'REPORTER_OCCUPATION_CODE', 'INITIAL_REPORT_TO_FDA', 
    'DATE_FACILITY_AWARE', 'DATE_REPORT_TO_MANUFACTURER', 'MANUFACTURER_CONTACT_L_NAME', 'MANUFACTURER_CONTACT_STREET_1', 'MANUFACTURER_CONTACT_STREET_2', 
    'MANUFACTURER_CONTACT_CITY', 'MANUFACTURER_CONTACT_ZIP_CODE', 'MANUFACTURER_CONTACT_ZIP_EXT', 'MANUFACTURER_CONTACT_COUNTRY', 'DEVICE_DATE_OF_MANUFACTURE', 
    'EVENT_TYPE', 'MANUFACTURER_CITY', 'MANUFACTURER_STATE_CODE', 'MANUFACTURER_ZIP_CODE', 'MANUFACTURER_COUNTRY_CODE', 'SOURCE_TYPE']
    '''
    MDR_Keys = df_mdrfoi[MDRFOI_titles[0]]
    for i in df_foidev.index:
        key = df_foidev.loc[i, 'MDR_REPORT_KEY']
        device_MDR_Hash[key] = df_foidev.loc[i][FOIDEV_titles].tolist()
    # Patient_Outcome, Event, Narrative
    new_df = df_mdrfoi
    length = new_df.shape[0]
    fill_values = ['' for x in range(length)]
    for t in FOIDEV_titles:
        new_df[t] = fill_values

    MDR_Link = MDR_Keys.apply(
        lambda s: 'http://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfMAUDE/Detail.cfm?MDRFOI__ID=%s' % s)

    date_received = new_df['DATE_RECEIVED']
    Report_Date = date_received.apply(lambda s: 'N/A' if s == '' else parser.parse(s))  # need insert
    Report_Year = date_received.apply(lambda s: 'N/A' if s == '' else parser.parse(s).year)  # need insert

    Event_Type = new_df['EVENT_TYPE']
    Event_Type = Event_Type.apply(lambda s: 'O' if ((s == '*') or (s == '')) else s)
    new_df['EVENT_TYPE'] = Event_Type

    Manufacture_DateStr = new_df['DEVICE_DATE_OF_MANUFACTURE']
    Manufacture_Date = Manufacture_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    Manufacture_Year = Manufacture_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s).year)

    Event_DateStr = new_df['DATE_OF_EVENT']
    Event_Date = Event_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    Event_Year = Event_DateStr.apply(lambda s: 'N/A' if s == '' else str(parser.parse(s).year))

    ReportMade_DateStr = new_df['DATE_REPORT']
    ReportMade_Date = ReportMade_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    ReportMade_Year = ReportMade_DateStr.apply(lambda s: 'N/A' if s == '' else str(parser.parse(s).year))

    ReportMan_DateStr = new_df['DATE_REPORT_TO_MANUFACTURER']
    ReportMan_Date = ReportMan_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    ReportMan_Year = ReportMan_DateStr.apply(lambda s: 'N/A' if s == '' else str(parser.parse(s).year))

    Time_to_Event = []

    for k in Manufacture_Date.index:
        if Manufacture_Date.loc[k] != 'N/A' and Event_Date.loc[k] != 'N/A' and Event_Date.loc[k] > Manufacture_Date.loc[
            k]:
            Time_to_Event.append(str((Event_Date.loc[k] - Manufacture_Date.loc[k]).days))

    else:
        Time_to_Event.append('N/A')

    Time_to_Event = pd.Series(Time_to_Event)

    Time_to_Report = []
    for k in Event_Date.index:
        if Event_Date.loc[k] != 'N/A' and Report_Date.loc[k] != 'N/A' and Report_Date.loc[k] > Event_Date.loc[k]:
            Time_to_Report.append(str((Report_Date.loc[k] - Event_Date.loc[k]).days))
        else:
            Time_to_Report.append('N/A')
    Time_to_Report = pd.Series(Time_to_Report)

    # get the Patient_Outcome, Event, Narrative
    Patient_Outcome = []
    Event = []
    Narrative = []
    flag = True
    print('begin parser other fields!')
    links = MDR_Link.values
    p = Pool(20)  # 20 process, acceleration
    results = p.map(Get_Other_Fields, links)
    print('end get other fields!')

    for res in results:
        Patient_Outcome.append(res[0])
        Event.append(res[1])
        Narrative.append(res[2])
    Patient_Outcome = pd.Series(Patient_Outcome)
    Event = pd.Series(Event)
    Narrative = pd.Series(Narrative)

    tmp_dict = {'Patient_Outcome': Patient_Outcome.values,
                'Event': Event.values,
                'Narrative': Narrative.values}
    tmp_df = pd.DataFrame.from_dict(tmp_dict)
    try:
        tmp_df.to_excel(save_dir + 'other_field.xls', index=False, header=True)
    except:
        print('other field save to xls field!')
        tmp_df.to_csv(save_dir + 'other_field.csv', index=False, header=True)

    # df_other = pd.read_excel(data_dir + 'other_field.xls')
    # Patient_Outcome = df_other['Patient_Outcome']
    # Event = df_other['Event']
    # Narrative = df_other['Narrative']

    new_df.insert(0, 'MDR_Link', MDR_Link)
    new_df.insert(1, 'Patient_Outcome', Patient_Outcome)
    new_df.insert(2, 'Event', Event)
    new_df.insert(3, 'Narrative', Narrative)
    new_df.insert(4, 'Manufacture Year', Manufacture_Year)
    new_df.insert(5, 'Event Year', Event_Year)
    new_df.insert(6, 'Report Year', Report_Year)
    new_df.insert(7, 'Time to Event', Time_to_Event)
    new_df.insert(8, 'Time to Report', Time_to_Report)

    print('copy from foidev')
    foi_data = {}
    for i in new_df.index:
        MDR_REPORT_KEY = new_df.loc[i]['MDR_REPORT_KEY']
        if (i == 0):
            print(device_MDR_Hash[MDR_REPORT_KEY])

        new_df.loc[i, FOIDEV_titles] = device_MDR_Hash[MDR_REPORT_KEY]

    # ew = pd.ExcelWriter('tttt.xlsx', options={'index':False, 'header':True, 'encoding':'utf-8'}) #data_dir+device_name+'_MAUDE_Data_'+str(end_year)+'.xlsx'
    try:
        new_df.to_excel(save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'full.xls', index=False, header=True)
    except:
        print('Merge Xlsx, save to xls file failed!')
        new_df.to_csv(save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'full.csv', index=False, header=True)
    # new_df.to_csv('tttt.csv', index=False, header=True)


def MergeMaudeCsv(current_year, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
                  MDRFOI_Field_Numbers, device_name, save_dir):
    """跟MergeMaudeXlsx功能基本差不多，只是这个是生成csv文件，且填充的字段要少一些，
    且最耗时的Get_Other_Fields函数的结果已经存在
    """
    infile = save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'mdrdev.csv'
    infile1 = save_dir + device_name + '_MAUDE_Data_' + str(current_year) + 'foidev.csv'
    outfile = save_dir + device_name + '_MAUDE_Data_' + str(current_year) + '.csv'
    df_mdrfoi = pd.read_csv(infile, dtype=str).fillna(value='')
    df_foidev = pd.read_csv(infile1, dtype=str).fillna(value='')
    MDRFOI_titles = df_mdrfoi.columns.tolist()
    FOIDEV_titles = df_foidev.columns.tolist()
    device_MDR_Hash = {'MDR_Key': FOIDEV_titles}
    del (FOIDEV_titles[0])
    MDR_Keys = df_mdrfoi[MDRFOI_titles[0]]
    for i in df_foidev.index:
        key = df_foidev.loc[i]['MDR_REPORT_KEY']
        device_MDR_Hash[key] = df_foidev.loc[i][FOIDEV_titles].tolist()

    print(FOIDEV_titles)
    print(MDRFOI_titles)

    # Patient_Outcome, Event, Narrative
    new_df = df_mdrfoi.fillna(value='')
    length = new_df.shape[0]
    fill_values = ['' for x in range(length)]
    for t in FOIDEV_titles:
        if (t != 'MDR_REPORT_KEY'):
            new_df[t] = fill_values
    MDR_Link = MDR_Keys.apply(
        lambda s: 'http://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfMAUDE/Detail.cfm?MDRFOI__ID=%s' % s)

    date_received = new_df['DATE_RECEIVED']
    Report_Date = date_received.apply(lambda s: 'N/A' if s == '' else parser.parse(s))  # need insert
    Report_Year = date_received.apply(lambda s: 'N/A' if s == '' else parser.parse(s).year)  # need insert

    Event_Type = new_df['EVENT_TYPE']
    Event_Type = Event_Type.apply(lambda s: 'O' if ((s == '*') or (s == '')) else s)
    new_df['EVENT_TYPE'] = Event_Type

    Manufacture_DateStr = new_df['DEVICE_DATE_OF_MANUFACTURE']
    Manufacture_Date = Manufacture_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    Manufacture_Year = Manufacture_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s).year)

    Event_DateStr = new_df['DATE_OF_EVENT']
    Event_Date = Event_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    Event_Year = Event_DateStr.apply(lambda s: 'N/A' if s == '' else str(parser.parse(s).year))

    ReportMade_DateStr = new_df['DATE_REPORT']
    ReportMade_Date = ReportMade_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    ReportMade_Year = ReportMade_DateStr.apply(lambda s: 'N/A' if s == '' else str(parser.parse(s).year))

    ReportMan_DateStr = new_df['DATE_REPORT_TO_MANUFACTURER']
    ReportMan_Date = ReportMan_DateStr.apply(lambda s: 'N/A' if s == '' else parser.parse(s))
    ReportMan_Year = ReportMan_DateStr.apply(lambda s: 'N/A' if s == '' else str(parser.parse(s).year))

    Time_to_Event = []
    for k in Manufacture_Date.index:
        if Manufacture_Date.loc[k] != 'N/A' and Event_Date.loc[k] != 'N/A' and Event_Date.loc[k] > Manufacture_Date.loc[
            k]:
            Time_to_Event.append(str((Event_Date.loc[k] - Manufacture_Date.loc[k]).days))
        else:
            Time_to_Event.append('N/A')
    Time_to_Event = pd.Series(Time_to_Event)

    Time_to_Report = []
    for k in Event_Date.index:
        if Event_Date.loc[k] != 'N/A' and Report_Date.loc[k] != 'N/A' and Report_Date.loc[k] > Event_Date.loc[k]:
            Time_to_Report.append(str((Report_Date.loc[k] - Event_Date.loc[k]).days))
        else:
            Time_to_Report.append('N/A')
    Time_to_Report = pd.Series(Time_to_Report)

    # get the Patient_Outcome, Event, Narrative
    df_other = pd.read_excel(save_dir + 'other_field.xls')
    # results = MDR_Link.apply(lambda l: Get_Other_Fields(l))
    Patient_Outcome = df_other['Patient_Outcome']
    Event = df_other['Event']
    Narrative = df_other['Narrative']

    for i in new_df.index:
        MDR_REPORT_KEY = new_df.loc[i]['MDR_REPORT_KEY']
        new_df.loc[i, FOIDEV_titles] = device_MDR_Hash[MDR_REPORT_KEY]

    res_df = pd.DataFrame([])
    res_df['MDR_Link'] = MDR_Link
    res_df['MDR_Key'] = MDR_Keys
    res_df['Event'] = Event
    res_df['Narrative'] = Narrative
    res_df['Event_Type'] = Event_Type
    res_df['Patient_Outcome'] = Patient_Outcome
    res_df['Manufacture Year'] = Manufacture_Year
    res_df['Event_Year'] = Event_Year
    res_df['Report_to_Manufacture_Year'] = ReportMan_Year
    res_df['Report_to_FDA'] = ReportMade_Year
    res_df['Report_Year'] = Report_Year
    res_df['Time_to_Event'] = Time_to_Event
    res_df['Time_to_Report'] = Time_to_Report
    res_df['Manufacturer'] = new_df['MANUFACTURER_D_NAME']
    res_df['Brand_Name'] = new_df['BRAND_NAME']
    res_df['Generic_Name'] = new_df['GENERIC_NAME']
    res_df['Product_Code'] = new_df['DEVICE_REPORT_PRODUCT_CODE']
    res_df.to_csv(outfile, index=False, header=True)


def MAUDE_Merge_Tables(current_year, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
                       MDRFOI_Field_Numbers, device_name, data_dir):  # ljn changed
    os.chdir(data_dir)

    MAUDE_Keys = []
    AllCounts = [0, 0, 0]

    # Optimized MAUDE Data Output
    # newbook = xlwt.Workbook("iso-8859-2")
    newbook = xlsxwriter.Workbook("iso-8859-2")
    # newsheet = newbook.add_sheet('Maude_Data', cell_overwrite_ok = True)
    newsheet = newbook.add_worksheet('Maude_Data')  # ljn added

    f1 = open('./' + device_name + '_MAUDE_Data_' + str(current_year) + '.csv', 'wb')
    csv_wr = csv.writer(f1, dialect='excel', delimiter=',')

    # Extract the Titles of Fields of Interest
    # FOIDEV_Titles
    with open(data_dir + FOIDEV_files[0] + '.txt', "rb") as foidev_file:
        # FOIDEV_Field_Numbers = get_numbers(FOIDEV_files[0]) # LJN CHANGED
        title = foidev_file.next()
        FOIDEV_titles = FieldExtract(title, FOIDEV_Field_Numbers)

    # MDRFOI_titles
    with open(data_dir + MDRFOI_files[0] + '.txt', "rb") as mdrfoi_file:
        # MDRFOI_Field_Numbers = get_numbers(MDRFOI_files[0])
        title = mdrfoi_file.next()
        MDRFOI_titles = FieldExtract(title, MDRFOI_Field_Numbers)

    # Create device_MDR_Hash
    device_MDR_Hash = {'MDR_Key': FOIDEV_titles}
    with open(device_name + '_FOIDEV.txt', "r") as foidev_file:
        # Skip the title
        title = foidev_file.next()
        for line in foidev_file:
            FOIDEV_Fields = line.split('|')
            MDR_Key = FOIDEV_Fields[0].strip()
            device_MDR_Hash[MDR_Key] = FOIDEV_Fields
            # print FOIDEV_Fields;
    print ('Number of records = ' + str(len(device_MDR_Hash)) + '\n')

    # Cross-match MDRFOI files to FOIDEV file
    curr_row = 0
    for filename in MDRFOI_files:
        with open(data_dir + filename + '.txt', 'rb') as mdrfoi_file:
            # Skip the title
            title = mdrfoi_file.next()

            # If first time, write the titles
            if (filename == MDRFOI_files[0]):
                newsheet.write(curr_row, 0, 'MDR_Link')
                newsheet.write(curr_row, 1, 'Patient_Outcome')
                newsheet.write(curr_row, 2, 'Event')
                newsheet.write(curr_row, 3, 'Narrative')
                newsheet.write(curr_row, 4, 'Manufacture Year')
                newsheet.write(curr_row, 5, 'Event Year')
                newsheet.write(curr_row, 6, 'Report Year')
                newsheet.write(curr_row, 7, 'Time to Event')
                newsheet.write(curr_row, 8, 'Time to Report')
                curr_col = 9
                # Write MDRFOI Titles
                for i in range(0, len(MDRFOI_titles)):
                    newsheet.write(curr_row, curr_col + i, MDRFOI_titles[i])  # xlwt不支持超过256行的写入们需要采用xlsxwriter
                # Write FOIDEBV Titles
                for i in range(0, len(FOIDEV_titles)):
                    newsheet.write(curr_row, curr_col + len(MDRFOI_titles) + i, FOIDEV_titles[i])
                    # Goto the next row
                curr_col = 0
                curr_row = 1

                csv_wr.writerow(['MDR_Link', 'MDR_Key', 'Event', 'Narrative', 'Event_Type', 'Patient_Outcome',
                                 'Manufacture Year', 'Event_Year', 'Report_to_Manufacture_Year', 'Report_to_FDA',
                                 'Report_Year', 'Time_to_Event', 'Time_to_Report',
                                 'Manufacturer', 'Brand_Name', 'Generic_Name', 'Product_Code'])

            # For each file, read Each Line and Cross-Match it to FOIDEV    
            for i, line in enumerate(mdrfoi_file):
                # st = time.time()
                MDRFOI_fields = FieldExtract(line, MDRFOI_Field_Numbers)

                MDR_Key = MDRFOI_fields[0]
                # print(MDRFOI_titles.index('EVENT_TYPE')) # 21, ljn changed
                Event_Type = MDRFOI_fields[MDRFOI_titles.index('EVENT_TYPE')]
                if MAUDE_Keys.count(MDR_Key) == 0:
                    MAUDE_Keys.append(MDR_Key)
                    AllCounts[0] = AllCounts[0] + 1
                    if Event_Type == 'D':
                        AllCounts[1] = AllCounts[1] + 1
                    elif Event_Type == 'IN':
                        AllCounts[2] = AllCounts[2] + 1

                if (device_MDR_Hash.has_key(MDR_Key)):  # or (MDR_Key == '2222833'):
                    # Get the report year
                    if (MDRFOI_fields[MDRFOI_titles.index('DATE_RECEIVED')] != ''):
                        Report_DateStr = MDRFOI_fields[MDRFOI_titles.index('DATE_RECEIVED')]
                        Report_Date = parser.parse(Report_DateStr)
                        Report_Year = str(Report_Date.year)
                    else:
                        Report_Date = 'N/A'
                        Report_Year = 'N/A'

                    # Only if the report year is before the end year
                    if (int(Report_Year) <= current_year):
                        # Get the rest of the fields from online records
                        MDR_Link = 'http://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfMAUDE/Detail.cfm?MDRFOI__ID=' + MDR_Key
                        print(str(curr_row) + '=' + MDR_Key + '\n')
                        try:
                            s = time.time()
                            [Patient_Outcome, Event, Narrative] = Get_Other_Fields(MDR_Link)
                            e = time.time()
                            print(1, e - s, MDR_Key)
                            # MDR_HLink = 'HYPERLINK("' + MDR_Link + '";"' + MDR_Link + '")'
                            MDR_HLink = 'HYPERLINK("' + MDR_Link + '";"' + MDR_Link + '")'

                            # Correct the EVENT Type
                            Event_Type = MDRFOI_fields[MDRFOI_titles.index('EVENT_TYPE')]
                            if (Event_Type == '*') or (Event_Type == ''):
                                Event_Type = 'O'

                            # Extract all the time fields
                            if (MDRFOI_fields[MDRFOI_titles.index('DEVICE_DATE_OF_MANUFACTURE')] != ''):
                                Manufacture_DateStr = MDRFOI_fields[
                                    MDRFOI_titles.index('DEVICE_DATE_OF_MANUFACTURE')].strip()
                                Manufacture_Date = parser.parse(Manufacture_DateStr)
                                Manufacture_Year = str(Manufacture_Date.year)
                            else:
                                Manufacture_Date = 'N/A'
                                Manufacture_Year = 'N/A'

                            if (MDRFOI_fields[MDRFOI_titles.index('DATE_OF_EVENT')] != ''):
                                Event_DateStr = MDRFOI_fields[MDRFOI_titles.index('DATE_OF_EVENT')]
                                Event_Date = parser.parse(Event_DateStr)
                                Event_Year = str(Event_Date.year)
                            else:
                                Event_Date = 'N/A'
                                Event_Year = 'N/A'

                            if (MDRFOI_fields[MDRFOI_titles.index('DATE_REPORT')] != ''):
                                ReportMade_DateStr = MDRFOI_fields[MDRFOI_titles.index('DATE_REPORT')]
                                ReportMade_Date = parser.parse(ReportMade_DateStr)
                                ReportMade_Year = str(ReportMade_Date.year)
                            else:
                                ReportMade_Date = 'N/A'
                                ReportMade_Year = 'N/A'

                            if (MDRFOI_fields[MDRFOI_titles.index('DATE_REPORT_TO_MANUFACTURER')] != ''):
                                ReportMan_DateStr = MDRFOI_fields[MDRFOI_titles.index('DATE_REPORT_TO_MANUFACTURER')]
                                ReportMan_Date = parser.parse(ReportMan_DateStr)
                                ReportMan_Year = str(ReportMan_Date.year)
                            else:
                                ReportMan_Date = 'N/A'
                                ReportMan_Year = 'N/A'

                            if Manufacture_Date != 'N/A' and Event_Date != 'N/A' and Event_Date > Manufacture_Date:
                                Time_to_Event = str((Event_Date - Manufacture_Date).days)
                            else:
                                Time_to_Event = 'N/A'
                            if Event_Date != 'N/A' and Report_Date != 'N/A' and Report_Date > Event_Date:
                                Time_to_Report = str((Report_Date - Event_Date).days)
                            else:
                                Time_to_Report = 'N/A'

                                # Write the extracted of MDRFOI Columns from online records

                            # newsheet.write(curr_row, 0, xlwt.Formula(MDR_HLink))
                            newsheet.write(curr_row, 0, MDR_Link)
                            newsheet.write(curr_row, 1, Patient_Outcome)
                            newsheet.write(curr_row, 2, Event)
                            newsheet.write(curr_row, 3, Narrative)
                            newsheet.write(curr_row, 4, Manufacture_Year)
                            newsheet.write(curr_row, 5, Event_Year)
                            newsheet.write(curr_row, 6, Report_Year)
                            newsheet.write(curr_row, 7, Time_to_Event)
                            newsheet.write(curr_row, 8, Time_to_Report)
                            curr_col = 9

                            # Write the rest of MDRFOI Columns
                            for i in range(0, len(MDRFOI_titles)):
                                if MDRFOI_titles[i].find('EVENT_TYPE') > -1:
                                    newsheet.write(curr_row, curr_col + i, Event_Type)
                                else:
                                    newsheet.write(curr_row, curr_col + i, MDRFOI_fields[i])
                            # Write FOIDEV Columns
                            for i in range(0, len(FOIDEV_titles)):
                                newsheet.write(curr_row, curr_col + len(MDRFOI_titles) + i, device_MDR_Hash[MDR_Key][i])

                                # Write selected columns to CSV file
                            Manufacturer = device_MDR_Hash[MDR_Key][4]
                            Brand_Name = device_MDR_Hash[MDR_Key][2]
                            Generic_Name = device_MDR_Hash[MDR_Key][3]
                            Product_Code = device_MDR_Hash[MDR_Key][6]
                            # print (Manufacturer)
                            # print (Brand_Name)
                            # print (Generic_Name)
                            # print (Product_Code)
                            csv_wr.writerow([MDR_Link, MDR_Key, Event, Narrative, Event_Type, Patient_Outcome,
                                             Manufacture_Year, Event_Year, ReportMan_Year, ReportMade_Year, Report_Year,
                                             Time_to_Event, Time_to_Report,
                                             Manufacturer, Brand_Name, Generic_Name, Product_Code])

                            # Remove the record from the hash to avoid duplicate records
                            device_MDR_Hash.pop(MDR_Key)

                            # Goto the next row
                            et2 = time.time()
                            print(2, et2 - e, MDR_Key)
                            print(filename, 'Extracted line %d' % i)
                            curr_row = curr_row + 1

                        except Exception as e:
                            print('Exception error in %s, ignore it!' % MDR_Key)

        mdrfoi_file.close()

    print (str(curr_row) + ' MDRFOI records cross-matched with FOIDEV records, and saved to the XLS file.')
    newbook.save(data_dir + device_name + '_MAUDE_Data_' + str(current_year) + '.xls')
    return AllCounts


def get_numbers(foi):
    '''
    每个文件的需要采集的numbers不一样，所以采用动态生成即可
    :param foi: foidev or mdrfoi filename
    :return:
    '''
    reader = open(data_dir + foi + '.txt', "rb")
    reader.next()
    line = reader.next()
    segs = line.split('|')
    num_list = []
    for i, s in enumerate(segs):
        if (s != ""):
            num_list.append(i + 1)

    reader.close()
    print(num_list)
    return num_list


###### Parameters
# Fields of interest (Numbers are based on Field Numbers provided on the FDA Website)
# FOIDEV_Field_Numbers = [1,2,7,8,9,19,26,27,29,30,31,34,36,44]
FOIDEV_Field_Numbers = [1, 2, 7, 8, 9, 19, 26, 27]  # 自2009年之后的数据，只有28个字段，09年之前的数据有45个字段
# MDRFOI_Field_Numbers = [1,2,3,4,6,7,8,9,10,11,12,14,16,17,25,26,27,28,30,31,32,68,69,70,72,75]
MDRFOI_Field_Numbers = [1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 14, 16, 17, 22, 25, 26, 27, 28, 30, 31, 32, 51, 56, 68, 69,
                        70, 72, 75]
# Years
start_year = 2000  # 2015 #2000
current_year = 2020  # 2014
end_year = 2019  # 2008 # 2013
# Device of Interest
device_name = ['daVinci', 'pacemaker', 'patient_monitor']
# Device Keywords
device_keywords = [['da vinci', 'davinci', 'davency', 'davincy', 'davincy',
                    'intuitive surgical', 'intuitivesurgical'], ['pacemaker']]
# Data Directory
data_dir = './datas/'
save_dir = './ExtractedFiles/' + str(current_year) + '/'

####### Generate the FOIDEV Filenames
FOIDEV_files = []
for years in range(start_year, current_year):
    FOIDEV_files.append('foidev' + str(years))
FOIDEV_files = FOIDEV_files + ['foidevadd', 'foidevchange', 'foidev', 'foitext']  # ljn changed
####### Generate the MDRFOI Filenames
# mdrfoithru2018.zip 解压后是mdrfoiThru2018.zip，foidevChnage.zip解压之后是foidevchange.txt,需要注意
MDRFOI_files = ['mdrfoithru' + str(current_year - 1), 'mdrfoi', 'mdrfoichange', 'mdrfoiadd']

####### Cross-match the MDRFOI and FOIDEV records
# AllCounts = MAUDE_Merge_Tables(end_year, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
#                    MDRFOI_Field_Numbers, device_name[0], data_dir)


if __name__ == '__main__':
    print('begin')
    # step 1
    ###### Download Maude Data
    # MAUDE_Download(FOIDEV_files, MDRFOI_files, './datas/')

    # step 2
    ###### Extract FOIDEV files and MDRFOI filesfor the device of interest
    # device_MDR_Hash = FOIDEVExtract(FOIDEV_files, FOIDEV_Field_Numbers, device_name[0], device_keywords[0], data_dir,
    #                                 save_dir)
    # MDRFOIExtract(device_MDR_Hash, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
    #                MDRFOI_Field_Numbers, device_name[0], data_dir, save_dir)

    # step 3
    ###### Merge FOIDEV and MDRFOI extracted into xlsx files
    MergeMaudeXlsx(current_year, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
                   MDRFOI_Field_Numbers, device_name[0], save_dir)

    # step 4
    ###### Merge FOIDEV and MDRFOI extracted into csv files
    MergeMaudeCsv(current_year, FOIDEV_files, MDRFOI_files, FOIDEV_Field_Numbers,
                   MDRFOI_Field_Numbers, device_name[0], save_dir)

    print('Check the reports that are not from intuitive to make sure they are related to da Vinci')
    print('The report 2222833 is manually added in order to compare with cardiac surgery records')
    print('end')
